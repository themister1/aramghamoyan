addon_id="script.icechannel.tmdb.settings"
addon_name="iStream - tmdb - Settings"
import xbmcaddon
addon = xbmcaddon.Addon(id=addon_id)
addon.openSettings()
