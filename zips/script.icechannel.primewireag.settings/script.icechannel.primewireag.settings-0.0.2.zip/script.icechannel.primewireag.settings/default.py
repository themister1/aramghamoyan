addon_id="script.icechannel.primewireag.settings"
addon_name="iStream - primewireag - Settings"
import xbmcaddon
addon = xbmcaddon.Addon(id=addon_id)
addon.openSettings()
