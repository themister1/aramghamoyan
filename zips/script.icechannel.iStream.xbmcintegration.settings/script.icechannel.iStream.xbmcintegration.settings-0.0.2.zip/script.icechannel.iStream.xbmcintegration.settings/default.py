addon_id="script.icechannel.iStream.xbmcintegration.settings"
addon_name="iStream - XBMC Integration - Settings"
import xbmcaddon
addon = xbmcaddon.Addon(id=addon_id)
addon.openSettings()
