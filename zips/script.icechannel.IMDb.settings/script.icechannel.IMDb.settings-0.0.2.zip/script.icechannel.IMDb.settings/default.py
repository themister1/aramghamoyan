addon_id="script.icechannel.IMDb.settings"
addon_name="iStream - IMDb - Settings"
import xbmcaddon
addon = xbmcaddon.Addon(id=addon_id)
addon.openSettings()
