addon_id="script.icechannel.trakt.settings"
addon_name="iStream - trakt - Settings"
import xbmcaddon
addon = xbmcaddon.Addon(id=addon_id)
addon.openSettings()
