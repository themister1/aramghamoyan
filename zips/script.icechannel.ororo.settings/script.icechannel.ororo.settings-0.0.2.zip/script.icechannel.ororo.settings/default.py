addon_id="script.icechannel.ororo.settings"
addon_name="iStream - ororo - Settings"
import xbmcaddon
addon = xbmcaddon.Addon(id=addon_id)
addon.openSettings()
